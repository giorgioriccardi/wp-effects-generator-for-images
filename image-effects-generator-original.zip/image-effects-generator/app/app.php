<?php

  // include('filters/all.php');

  include('filters/black_and_white.php');
  include('filters/negative.php');
  include('filters/blurred.php');
  include('filters/sharpen.php');
  include('filters/sepia.php');
  include('filters/pixelate.php');

  include('show_sizes.php');

  unset( $my_options );

?>