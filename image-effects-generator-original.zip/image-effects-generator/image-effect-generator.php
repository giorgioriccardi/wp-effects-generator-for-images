<?php
  /*
    Plugin Name: Image Effects Generator
    Plugin URI: http://dev.twoblok.es/wp-image-effect-generator
    Description: A plugin that generates selected image effects on upload.
    Version: 1.0.1
    Author: Two Blokes
    Author URI: http://twoblok.es
    License: GPL2
  */

  include('settings/settings_page.php');

  include('app/app.php');

?>